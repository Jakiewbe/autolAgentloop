# 面板修复补充包 dashboard-item-key-cancel-v2

范围：dashboard/ 面板源码、单测、说明，以及本轮隔离验证脚本与修复报告。不含配置、身份、密钥、日志、运行截图，不含 app/、.agent/、B/ 任何文件。

v2 取代 v1（v1 冻结、原样保留，可整包回退）。相对 v1 只做 round3 的六点定点收尾，不扩功能。

## 相对 v1 的改动

1. 取消回执：中心记为 cancelled 时只说“中心已确认这轮已取消。是否曾经开始执行，请看这轮的执行时间线；面板不据此推断。”不再一律称排队任务不会开始。
2. 心跳折叠：只折叠确认纯保活的心跳；changes 里带 cards 行（关闭离线通知）、runs 行 state 变化、session 变化的，按真实变化单列，事实仍全部保留且保序。
3. 关闭卡片：closed 且无 result 只说“已关闭（仅告知或已结案），没有处理结果记录”，不替它记人工结案（fyi 可能创建即 closed）。
4. 状态待确认：按中心租约语义说明“还没有确认结束状态（例如运行中超过租约仍未回报）”，不猜重试次数，仍不接受取消、无伪造停止入口。
5. 空 lane：只说“对象标识为空”，按规则 + 空对象归组，不推断是否配过 parallel、不倒推历史规则。
6. 取消核对：refresh 返回本次读取的明确结果；提交后仅当这次最新读取成功才用其数据下结论，被跳过或失败一律显示未确认；随后恢复较早历史页不会把未确认改成确认。未新增自动重试或业务状态。

## 应用

1. 先备份现有 dashboard/ 目录（本包为覆盖式全文件包，PATCH.json 记 v1 与 v2 的逐文件哈希）。
2. 按 PATCH.json 的 path 覆盖同名文件；dashboard/app-text.test.mjs 为新增文件。
3. cd dashboard && node --test server.test.mjs app-text.test.mjs 应 34 通过。
4. 需要浏览器核验时：node evidence/dashboard-workflow/fixture-v2.mjs（3353，隔离假中心），再 node evidence/dashboard-workflow/browser-qa.mjs（11 项全过）。每次重跑前重启 fixture。

## 回退

还原备份目录，或重新应用冻结的 v1 包（dashboard-item-key-cancel-v1.zip，52640 字节）；面板三种写操作与只读展示不变，回退不涉及中心、worker 或规则。

## 边界

本包没有部署、没有重启中心或 3351、没有派发真实模型、没有操作生产卡片，也不构成产品验收：需统筹复核并由 B 用固定包真实复测后才可宣告。第 6 点的两条时序场景目前在单元层覆盖（未新增浏览器级时序用例）。
