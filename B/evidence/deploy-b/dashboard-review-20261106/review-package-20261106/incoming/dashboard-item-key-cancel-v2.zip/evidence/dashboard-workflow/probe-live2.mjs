
import { createDashboard } from "../../dashboard/server.mjs";
import { readFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
const config = JSON.parse(readFileSync(join(homedir(), ".agent-autoloop", "config.json"), "utf8"));
const server = createDashboard({ owner: config.owner, hubUrl: config.url });
await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
const port = server.address().port;
const res = await fetch("http://127.0.0.1:" + port + "/api/state", { headers: { Authorization: "Bearer " + config.owner } });
const st = await res.json();
await new Promise((resolve) => server.close(resolve));
for (const r of st.runs.slice(0, 3)) console.log(r.id, JSON.stringify(r.lane), r.laneKnown, JSON.stringify(r.grp));
const lanes = new Map();
for (const r of st.runs) { const k = JSON.stringify([r.rule, r.lane]); lanes.set(k, (lanes.get(k) || 0) + 1); }
console.log("runs", st.runs.length, "distinct items", lanes.size);
console.log([...lanes.entries()].map(([k, n]) => k + " x" + n).join(" | "));
