
import { createDashboard } from "../../dashboard/server.mjs";
import { readFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
const config = JSON.parse(readFileSync(join(homedir(), ".agent-autoloop", "config.json"), "utf8"));
const server = createDashboard({ owner: config.owner, hubUrl: config.url });
await new Promise((r) => server.listen(0, "127.0.0.1", r));
const base = "http://127.0.0.1:" + server.address().port;
const why = await (await fetch(base + "/api/runs/30/why")).json();
console.log("why keys", Object.keys(why), "facts", why.facts?.length);
const state = await (await fetch(base + "/api/state")).json();
console.log("runs", state.runs.length, "known", state.runs.filter((r) => r.laneKnown).length, "unlinked", state.runs.filter((r) => !r.laneKnown).length);
console.log("first", state.runs.slice(0, 4).map((r) => [r.id, r.rule, JSON.stringify(r.lane), r.grp, r.laneKnown]));
server.close();
