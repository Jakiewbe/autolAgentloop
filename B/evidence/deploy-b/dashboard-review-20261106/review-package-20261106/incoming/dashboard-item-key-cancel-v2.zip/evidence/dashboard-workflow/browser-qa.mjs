// Browser verification through the Chrome DevTools protocol: no framework, no extra dependency.
import { spawn } from "node:child_process";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const CHROME = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
const BASE = process.env.QA_BASE || "http://127.0.0.1:3353";
const OUT = "evidence/dashboard-workflow";
const profile = mkdtempSync(join(tmpdir(), "dash-qa-"));
const child = spawn(
  CHROME,
  [
    "--headless=new",
    "--disable-gpu",
    "--no-first-run",
    "--no-default-browser-check",
    "--window-size=1440,1400",
    "--remote-debugging-port=9333",
    "--user-data-dir=" + profile,
    BASE + "/",
  ],
  { stdio: "ignore" },
);

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function target() {
  for (let step = 0; step < 40; step += 1) {
    try {
      const list = await (
        await fetch("http://127.0.0.1:9333/json/list")
      ).json();
      const page = list.find(
        (item) => item.type === "page" && item.url.startsWith(BASE),
      );
      if (page) return page;
    } catch {}
    await sleep(250);
  }
  throw Error("no page target");
}
const page = await target();
const socket = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener("open", resolve, { once: true });
  socket.addEventListener("error", reject, { once: true });
});
let seq = 0;
const pending = new Map();
socket.addEventListener("message", (event) => {
  const data = JSON.parse(event.data);
  const slot = pending.get(data.id);
  if (!slot) return;
  pending.delete(data.id);
  if (data.error) slot.reject(Error(JSON.stringify(data.error)));
  else slot.resolve(data.result);
});
const send = (method, params = {}) =>
  new Promise((resolve, reject) => {
    const id = ++seq;
    pending.set(id, { resolve, reject });
    socket.send(JSON.stringify({ id, method, params }));
  });
await send("Page.enable");
await send("Runtime.enable");
const evaluate = async (expression) => {
  const out = await send("Runtime.evaluate", {
    expression,
    awaitPromise: true,
    returnByValue: true,
  });
  if (out.exceptionDetails)
    throw Error(
      out.exceptionDetails.exception?.description || "evaluate failed",
    );
  return out.result.value;
};
const shot = async (name) => {
  await sleep(350);
  const { data } = await send("Page.captureScreenshot", { format: "png" });
  writeFileSync(join(OUT, name), Buffer.from(data, "base64"));
};
const results = [];
const check = (name, pass, detail) => {
  results.push({ name, pass: Boolean(pass), detail });
  console.log(
    (pass ? "PASS " : "FAIL ") + name + " :: " + JSON.stringify(detail),
  );
};

await sleep(1200);
await evaluate(
  "window.__wait = async function (probe) { for (var step = 0; step < 100; step += 1) { var ok = false; try { ok = probe(); } catch (error) { ok = false; } if (ok) return true; await new Promise(function (r) { setTimeout(r, 100); }); } return false; };",
);

// 1. Overview reads the newest snapshot.
const overview = await evaluate(
  "(async function () { location.hash = '#overview'; await window.__wait(function () { return document.querySelector('#nav-runs') && document.querySelector('#nav-runs').textContent === '20'; }); return { nav: document.querySelector('#nav-runs').textContent, title: document.querySelector('#page-title').textContent }; })()",
);
check(
  "overview counts only the runs of the newest snapshot",
  overview.nav === "20",
  overview,
);
await shot("qa-overview.png");

// 2. Items follow rule + lane.
const items = await evaluate(
  "(async function () { location.hash = '#items'; await window.__wait(function () { var el = document.querySelector('#view-content'); return !!el && el.textContent.indexOf('事项按中心自己的归属关联') >= 0; }); var groups = [].slice.call(document.querySelectorAll('.item-group')); return { count: groups.length, titles: groups.map(function (g) { return g.querySelector('h2').textContent; }), rows: groups.map(function (g) { return [].slice.call(g.querySelectorAll('[data-run]')).map(function (b) { return Number(b.dataset.run); }); }), unlinked: groups.filter(function (g) { return g.querySelector('h2').textContent.indexOf('未关联') >= 0; }).length }; })()",
);
const laneA = items.titles.indexOf("obj-A");
const laneB = items.titles.indexOf("obj-B");
check(
  "items split the two lanes of one parallel rule",
  laneA >= 0 &&
    laneB >= 0 &&
    items.rows[laneA].join(",") === "100" &&
    items.rows[laneB].join(",") === "99",
  { count: items.count, titles: items.titles, rows: items.rows },
);
check("no item is invented without the hub's own lane", items.unlinked === 0, {
  unlinked: items.unlinked,
});
await shot("qa-items.png");

// 3. Timeline folds consecutive heartbeats and keeps state changes.
const timeline = await evaluate(
  "(async function () { location.hash = '#runs'; await window.__wait(function () { return !!document.querySelector('button[data-run=\"100\"]'); }); document.querySelector('button[data-run=\"100\"]').click(); await window.__wait(function () { return !!document.querySelector('#run-timeline details, #run-timeline ol.timeline'); }); var details = document.querySelector('#run-timeline details'); var summary = details ? details.querySelector('summary').textContent : ''; var folded = details ? details.querySelectorAll('ol.timeline-nested li').length : 0; if (details) details.open = true; var labels = [].slice.call(document.querySelectorAll('#run-timeline > ol.timeline > li')).map(function (li) { var strong = li.querySelector('strong'); return strong ? strong.textContent : 'folded-heartbeats'; }); var top = document.querySelectorAll('#run-timeline > ol.timeline > li').length; return { summary: summary, folded: folded, labels: labels, top: top }; })()",
);
check(
  "consecutive heartbeats fold into one expandable group of six facts",
  timeline.summary.indexOf("连续 6 条执行端心跳") >= 0 && timeline.folded === 6,
  timeline,
);
check(
  "state changes stay explicit beside the folded heartbeats",
  timeline.labels.indexOf("执行端领取") >= 0 &&
    timeline.labels.indexOf("开始执行") >= 0,
  timeline.labels,
);
await shot("qa-timeline.png");

// 4. Cancel wording comes from the refreshed hub state.
const claimedCancel = await evaluate(
  "(async function () { var button = document.querySelector('[data-stop-run=\"100\"]'); var note = document.querySelector('.detail-body .soft-note') ? document.querySelector('.detail-body .soft-note').textContent : ''; button.click(); await window.__wait(function () { return !!document.querySelector('#cancel-form button[type=submit]'); }); document.querySelector('#cancel-form button[type=submit]').click(); await window.__wait(function () { return !document.querySelector('#action-message').hidden; }); return { note: note, message: document.querySelector('#action-message').textContent }; })()",
);
check(
  "a recorded cancel waits for the runner to confirm stopping",
  claimedCancel.message.indexOf("等待执行端确认停止") >= 0,
  claimedCancel,
);
const unknownCase = await evaluate(
  "(async function () { document.querySelector('#run-detail').close(); document.querySelector('button[data-run=\"96\"]').click(); await window.__wait(function () { return !!document.querySelector('#run-timeline'); }); var stop = [].slice.call(document.querySelectorAll('[data-stop-run]')).some(function (b) { return b.dataset.stopRun === '96'; }); var notes = [].slice.call(document.querySelectorAll('.detail-body .soft-note')).map(function (n) { return n.textContent; }).join(' '); return { stop: stop, notes: notes }; })()",
);
check(
  "an unknown round has no stop control and explains the limit",
  unknownCase.stop === false && unknownCase.notes.indexOf("不接受取消") >= 0,
  unknownCase,
);
const unrecorded = await evaluate(
  "(async function () { var dismiss = document.querySelector('[data-dismiss-message]'); if (dismiss) dismiss.click(); document.querySelector('#run-detail').close(); document.querySelector('button[data-run=\"97\"]').click(); await window.__wait(function () { return !!document.querySelector('[data-stop-run=\"97\"]'); }); document.querySelector('[data-stop-run=\"97\"]').click(); await window.__wait(function () { return !!document.querySelector('#cancel-form button[type=submit]'); }); document.querySelector('#cancel-form button[type=submit]').click(); await window.__wait(function () { var box = document.querySelector('#action-message'); return !!box && !box.hidden && box.textContent.indexOf('取消') >= 0 && box.textContent.indexOf('中心没有记录') >= 0; }); var box = document.querySelector('#action-message'); return box.hidden ? 'hidden' : box.textContent; })()",
);
check(
  "an unrecorded cancel is reported as unrecorded, not as stopped",
  unrecorded.indexOf("中心没有记录取消请求") >= 0,
  unrecorded,
);
await shot("qa-cancel.png");

// 5. An older page never stands in for the newest snapshot.
const history = await evaluate(
  "(async function () { document.querySelector('#run-detail').close(); await window.__wait(function () { return !!document.querySelector('#older-page'); }); document.querySelector('#older-page').click(); await window.__wait(function () { return !!document.querySelector('#older-page'); }); document.querySelector('#older-page').click(); await window.__wait(function () { var foot = document.querySelector('.table-footer span'); return !!foot && foot.textContent.indexOf('较早') >= 0; }); var olderIds = [].slice.call(document.querySelectorAll('button[data-run]')).map(function (b) { return b.dataset.run; }); var older = olderIds.length; location.hash = '#overview'; await window.__wait(function () { return !!document.querySelector('.banner-note'); }); var banner = document.querySelector('.banner-note') ? document.querySelector('.banner-note').textContent : ''; var nav = document.querySelector('#nav-runs') ? document.querySelector('#nav-runs').textContent : ''; var activeShown = [].slice.call(document.querySelectorAll('#view-content [data-run]')).some(function (b) { return b.dataset.run === '100'; }); location.hash = '#runs'; await window.__wait(function () { return !!document.querySelector('#latest-page') || !!document.querySelector('#older-page'); }); var stillOlder = document.querySelectorAll('button[data-run]').length; return { older: older, olderIds: olderIds, banner: banner, nav: nav, activeShown: activeShown, stillOlder: stillOlder }; })()",
);
check(
  "the overview after history comes from the newest snapshot and says so",
  history.banner.indexOf("较早的历史记录页") >= 0 &&
    history.banner.indexOf("最新快照") >= 0 &&
    history.nav === "20" &&
    history.activeShown &&
    history.stillOlder === history.older &&
    history.olderIds.indexOf("100") < 0,
  history,
);
await shot("qa-history.png");

// 6. A decided card without a result says only that.
const decided = await evaluate(
  "(async function () { location.hash = '#attention'; await window.__wait(function () { var el = document.querySelector('#view-content'); return !!el && el.textContent.indexOf('最近决定与处理结果') >= 0; }); var cards = [].slice.call(document.querySelectorAll('.attention-card')); var target = cards.filter(function (c) { return c.textContent.indexOf('已回答但没有后续') >= 0; })[0]; var closed = cards.filter(function (c) { return c.textContent.indexOf('已关闭（仅告知') >= 0; })[0]; return { wording: target && target.querySelector('.decision-answer') ? target.querySelector('.decision-answer').textContent : '', note: !!target && target.textContent.indexOf('面板不提供结案入口') >= 0, closed: closed && closed.querySelector('.decision-answer') ? closed.querySelector('.decision-answer').textContent : '' }; })()",
);
check(
  "a decided card explains the missing result without promising one",
  decided.wording.indexOf("中心尚未收到后续结果") >= 0 && decided.note,
  decided,
);
check(
  "a closed card without a result credits no human handling",
  decided.closed.indexOf("没有处理结果记录") >= 0 &&
    decided.closed.indexOf("人工") < 0,
  decided.closed,
);
await shot("qa-attention.png");

const passed = results.filter((r) => r.pass).length;
console.log(
  "SUMMARY " +
    JSON.stringify({
      total: results.length,
      passed: passed,
      failed: results.length - passed,
    }),
);
writeFileSync(
  join(OUT, "browser-qa-result.json"),
  JSON.stringify(
    {
      base: BASE,
      results: results,
      passed: passed,
      failed: results.length - passed,
    },
    null,
    2,
  ) + "\n",
);
socket.close();
child.kill();
process.exit(passed === results.length ? 0 : 1);
