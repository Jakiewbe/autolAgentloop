// Isolated fixture: the dashboard's own server plus a fabricated hub that never touches the real one.
// It exists to prove the panel reads lanes, cancels, folding and page boundaries the way the contract says.
import { createDashboard } from "../../dashboard/server.mjs";

const LANES = { 100: "obj-A", 99: "obj-B", 97: "obj-A" };
const done = Array.from({ length: 63 }, (_, index) => 63 - index).map((id) => ({
  id,
  rule: id % 3 === 0 ? "并行" : "日常",
  agent: "b",
  state: "done",
  attempts: 0,
  createdAt: `2026-11-05T0${id % 10}:00:00.000Z`,
  finishedAt: `2026-11-05T0${id % 10}:30:00.000Z`,
  summary: id === 30 ? "第三十轮" : "第" + id + "轮完成",
  session: "sess-" + id,
  usage: { input: 100 + id, output: 10, cached: 0, cost: null },
  events: [],
}));
const runs = [
  {
    id: 100,
    rule: "并行",
    agent: "b",
    state: "claimed",
    attempts: 0,
    createdAt: "2026-11-06T06:00:00.000Z",
    claimedAt: "2026-11-06T06:00:01.000Z",
    session: "sess-100",
    stopping: false,
    summary: "",
    events: [],
  },
  {
    id: 99,
    rule: "并行",
    agent: "b",
    state: "claimed",
    attempts: 0,
    createdAt: "2026-11-06T05:58:00.000Z",
    claimedAt: "2026-11-06T05:58:01.000Z",
    session: "sess-99",
    summary: "",
    events: [],
  },
  {
    id: 98,
    rule: "恢复",
    agent: "b",
    state: "queued",
    attempts: 2,
    createdAt: "2026-11-06T05:50:00.000Z",
    notBefore: "2026-11-06T07:30:00.000Z",
    summary: "",
    events: [],
  },
  {
    id: 97,
    rule: "长跑",
    agent: "b",
    state: "claimed",
    attempts: 0,
    createdAt: "2026-11-06T05:40:00.000Z",
    claimedAt: "2026-11-06T05:40:01.000Z",
    session: "sess-97",
    summary: "",
    events: [],
  },
  {
    id: 96,
    rule: "长跑",
    agent: "b",
    state: "unknown",
    attempts: 5,
    createdAt: "2026-11-06T05:30:00.000Z",
    claimedAt: "2026-11-06T05:30:01.000Z",
    error: "超出重试范围",
    summary: "",
    events: [],
  },
  ...done,
];

const cards = [
  {
    id: 5,
    kind: "ask",
    state: "open",
    title: "选一个对象继续",
    text: "并行规则要按对象决定下一步。",
    options: ["甲", "乙"],
    rule: "并行",
    createdAt: "2026-11-06T06:10:00.000Z",
  },
];
const recentCards = [
  {
    id: 4,
    kind: "ask",
    state: "decided",
    title: "已回答但没有后续",
    text: "回答后中心没有回报结果。",
    choice: 0,
    options: ["甲", "乙"],
    answer: "甲",
    result: null,
    rule: "并行",
    createdAt: "2026-11-06T05:00:00.000Z",
    decidedAt: "2026-11-06T05:01:00.000Z",
  },
  {
    id: 3,
    kind: "notice",
    state: "closed",
    title: "已人工结案",
    text: "这条通知已结案。",
    rule: "长跑",
    createdAt: "2026-11-06T04:00:00.000Z",
    closedAt: "2026-11-06T04:05:00.000Z",
  },
];

const lines = [
  {
    name: "并行",
    source: "test",
    agent: "b",
    types: ["job"],
    parallel: "obj",
    next: null,
    every: null,
    totals: { done: 21 },
  },
  {
    name: "日常",
    source: "test",
    agent: "b",
    types: ["daily"],
    parallel: null,
    next: "2026-11-07T01:00:00.000Z",
    every: "每天",
    totals: { done: 42 },
  },
];

const pageSize = 20;
function page(before) {
  const from =
    before === null ? 0 : runs.findIndex((run) => run.id === before) + 1;
  const slice = runs.slice(from, from + pageSize);
  const hasMore = from + pageSize < runs.length;
  return {
    now: "2026-11-06T07:00:00.000Z",
    timezone: "Asia/Shanghai",
    totals: {
      running: 3,
      queued: 1,
      retrying: 1,
      unknown: 1,
      done: 63,
      attention: 1,
    },
    spending: {
      today: {
        rounds: 12,
        tokens: 3400,
        cost: null,
        missingTokens: 0,
        missingCost: 12,
      },
    },
    agents: [
      {
        id: "b",
        name: "B / MagicBook14",
        worker: "b",
        use: "command",
        online: true,
        seenAt: "2026-11-06T06:59:40.000Z",
        totals: { done: 63 },
      },
    ],
    runs: slice,
    cards,
    recentCards,
    sources: [{ id: "test", name: "测试来源", events: 12 }],
    channels: [
      { id: "b", name: "B", online: true, seenAt: "2026-11-06T06:59:40.000Z" },
    ],
    lines,
    elsewhere: [
      {
        id: "daily",
        name: "早报",
        agent: "claude",
        next: "2026-11-06T23:00:00.000Z",
        every: "每天",
        where: "其他应用",
      },
    ],
    unrouted: [],
    hasMore,
    nextBefore: hasMore ? slice[slice.length - 1].id : null,
  };
}

function facts(id) {
  const lane = LANES[id];
  const base = [
    {
      seq: 1,
      at: "2026-11-06T06:00:00.000Z",
      type: "claimNext",
      changes: [
        {
          table: "runs",
          key: id,
          row: {
            id,
            state: "claimed",
            lane: lane ?? "",
            grp: lane ? "并行" : "日常",
            session: "sess-" + id,
          },
        },
      ],
    },
    {
      seq: 2,
      at: "2026-11-06T06:00:02.000Z",
      type: "started",
      changes: [
        {
          table: "events",
          key: 40 + id,
          row: { source: "test", type: "job", subject: "subject-" + id },
        },
      ],
    },
  ];
  // A real heartbeat always carries a seen row, a runs row and a due row; the runs row is
  // what keeps the fact in the projected timeline, so the fixture must carry it too.
  const beat = (step) => ({
    seq: 3 + step,
    at: "2026-11-06T06:0" + (1 + step) + ":00.000Z",
    type: "heartbeat",
    changes: [
      {
        table: "seen",
        key: "worker:b",
        row: {
          kind: "worker",
          name: "b",
          seen_at: "2026-11-06T06:0" + (1 + step) + ":00.000Z",
        },
      },
      {
        table: "runs",
        key: id,
        row: {
          id,
          state: "claimed",
          lane: lane ?? "",
          grp: lane ? "并行" : "日常",
        },
      },
      {
        table: "due",
        key: "offline:b",
        row: { kind: "offline", key: "b", at: 0 },
      },
    ],
  });
  if (id === 100) for (let step = 0; step < 6; step += 1) base.push(beat(step));
  if (id === 99) base.push(beat(4));
  return base;
}

const fetchImpl = async (target, options = {}) => {
  const url = String(target);
  const method = options.method || "GET";
  if (method === "POST") {
    const cancel = url.match(/\/v1\/runs\/(\d+)\/cancel/);
    if (cancel) {
      const id = Number(cancel[1]);
      const run = runs.find((item) => item.id === id);
      // 100 records the request; 97 answers ok but records nothing, as a hub may.
      if (id === 100) {
        if (run) run.stopping = true;
        return Response.json({ ok: true, changed: true, state: "claimed" });
      }
      if (id === 97)
        return Response.json({ ok: true, changed: false, state: "claimed" });
      return new Response(JSON.stringify({ error: "这一轮已经结束了" }), {
        status: 409,
      });
    }
    const answer = url.match(/\/v1\/cards\/(\d+)\/(answer|resolve)/);
    if (answer) return Response.json({ changed: true, state: "decided" });
    return new Response("no", { status: 404 });
  }
  const why = url.match(/\/v1\/runs\/(\d+)\/why/);
  if (why) return Response.json(facts(Number(why[1])));
  const before = new URL(url).searchParams.get("before");
  return Response.json(page(before === null ? null : Number(before)));
};

const server = createDashboard({
  owner: "FIXTURE_OWNER",
  hubUrl: "http://fixture.invalid",
  fetchImpl,
});
const port = Number(process.env.FIXTURE_PORT || 3353);
server.listen(port, "127.0.0.1", () =>
  console.log("fixture dashboard http://127.0.0.1:" + port),
);
