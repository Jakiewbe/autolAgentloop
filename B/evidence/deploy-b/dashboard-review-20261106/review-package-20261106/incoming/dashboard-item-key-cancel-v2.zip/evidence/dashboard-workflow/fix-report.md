# 面板修复报告（round2 审核缺陷 → 本轮修复）

范围：`dashboard/`（server.mjs、public/app.js、public/workflow.mjs、public/styles.css、server.test.mjs、README.md）。未改 app/、.agent/、B/、活动配置、权限、身份、模型、MCP、登录项；未重启中心或 worker；未派发真实模型；未操作生产卡片；未提交、未推送。

## 一、逐条对照

| 编号 | round2 原问题 | 本次修复 | 位置 | 验证 |
| --- | --- | --- | --- | --- |
| B1/B2/B4 | 事项键用 source+subject，与中心真实 rule+lane 不符；测试把错口径固化 | 分组只看该轮 why 事实里 runs 行的 lane + rule；无权威字段标 unlinked，不按标题/事件/会话猜，不用当前 parallel 反推旧轮，不写死 17 | dashboard/public/workflow.mjs:15 groupItems、:41 itemTitle、:48 itemNote；dashboard/server.mjs:227 laneOf、:255 readLane、:268 attachLanes、:496 挂载到 /api/state | server.test.mjs:521「items follow the hub's rule and lane…」（7 组、空 lane、同会话、不同 rule 同 subject、历史 parallel 两 lane、缺字段 unlinked）、:591 laneOf、:618 state 只请求一次且失败降级 |
| D3 | queued 取消文案与 decide.ts:525 相悖（说成等待确认） | 按中心状态分支：queued→已记为取消、不会开始；claimed→只是请求、等执行端确认；claimed+stopping→等待确认；找不到→请回到最新核对；刷新失败→没能确认、勿重复提交 | workflow.mjs:80 cancelNote；app.js:262 resultText 无关，取消在 submit 成功路径 | server.test.mjs:693 七分支；浏览器 QA「a recorded cancel waits for the runner to confirm stopping」「an unrecorded cancel is reported as unrecorded」 |
| D5 | unknown 无取消路径且未说明 | 详情页与取消回执都写明：状态待确认的轮次中心不接受取消，面板不提供伪造停止入口 | app.js:349 stopNote；workflow.mjs:80 unknown 分支 | QA「an unknown round has no stop control and explains the limit」 |
| A5 | decided 卡不能结案却未写明；后续结果语义含糊 | 历史卡显示「中心尚未收到后续结果。这只说明现在没有结果，不保证后面一定会执行，也不表示要永远等下去。」并注明中心只接受对等待回答的卡片结案、已回答的等后续回报、面板不提供结案入口；closed 显示「已人工结案，未记录后续结果。」 | app.js:262 resultText、:271 decisionCard | QA「a decided card explains the missing result without promising one」「a closed card is described as manually closed」 |
| C6 | 心跳淹没时间线 | 连续纯心跳折叠为可展开组（保留每一条、保序），领取/开始/回答/取消/结束单列 | workflow.mjs:67 timelineNodes；app.js:386 timelineHtml；styles.css .timeline-heartbeat | server.test.mjs:670；QA「consecutive heartbeats fold into one expandable group of six facts」+「state changes stay explicit」 |
| E5 | 历史页的总览漏掉活动轮 | 历史分页只服务任务记录页；切到总览/计划等一律改用最近一次成功读取的最新快照，并显示「刚才查看的是较早的历史记录页…最新快照（时间）」 | app.js:79/646 historyLeft、:313 banner、:543 refresh（page/latest 分离） | QA「the overview after history comes from the newest snapshot and says so」（历史页 20 条全为旧轮，总览 20 轮且含活动轮 100，返回记录页仍是原历史页） |
| G4 | healthz 字段命名易误读（readOnly:false） | 改为 `{app, version:"workflow-2", writes:[cards/answer, cards/resolve, runs/cancel]}` | server.mjs:458-466 | server.test.mjs:658 |

## 二、数字

- 服务端单测：`cd dashboard && node --test server.test.mjs` → tests 28 / pass 28 / fail 0（约 0.39s）。
- 浏览器验证：`node evidence/dashboard-workflow/browser-qa.mjs`（fixture-v2 3353，headless Chrome CDP）→ 11 项 / 11 通过 / 0 失败；截图 qa-overview.png、qa-items.png、qa-timeline.png、qa-cancel.png、qa-history.png、qa-attention.png。
- 真实中心只读核验（未写入、未派发）：35 轮 / laneKnown 35 / unlinked 0；按 (rule, lane) 聚合得 17 个事项，其中「B-接线验证」6 轮、「试一下」6 轮、「V2-验收」2 轮，一条 parallel 规则的两个 lane 各自成组。17 来自数据，不是常量。
- 格式化：prettier --check 本轮 7 个源码/测试文件全部通过。

## 三、遗留与边界

- 面板仍只做只读展示 + 三种本人写操作；不提供任何伪造的停止/结案能力。
- lane 注入依赖中心 `/v1/runs/<id>/why`；该接口不可用时整页仍可读，只是这些轮次标「未关联」，不猜测。
- 真实中心 35 轮各取一次 why 的实测成本约 289ms（并发 6，仅首次；之后命中缓存）。
- 浏览器断言依赖 fixture 内存状态：每次重跑前重启 `node evidence/dashboard-workflow/fixture-v2.mjs`。
- 本包不构成产品验收：需统筹复核、并由 B 用固定包真实复测后才能宣告。


## 四、round3 定点收尾（v2，2026-11-06 20:xx +08）

v1 固定包已冻结未重写（52640 字节 / sha256 b9cb373f…d76d7c）。本轮只按 round3 六个明确点收尾，不扩功能、不改中台/生产配置/B、未部署、未重启中心或 3351、未派发真实模型、未提交推送。

| 编号 | round3 问题 | 修法 | 位置 | 验证 |
| --- | --- | --- | --- | --- |
| 1 | cancelled 回执一律说「排队任务不会开始」 | 改中性：只写「中心已确认这轮已取消。是否曾经开始执行，请看这轮的执行时间线；面板不据此推断。」claimedAt 存在时同样不推断 | dashboard/public/workflow.mjs:85-87 cancelNote | server.test.mjs「cancel wording follows…」改为断言中性文案且不含「不会开始执行/排队任务」；Round3 独立探针同断言 |
| 2 | timelineNodes 只按 type=heartbeat 折叠，真实心跳会关离线通知 | 只折叠确认纯保活的心跳：changes 里出现 cards 行、或 runs 行 state 变化、或 session 变化，一律单列；seen/due 行不阻止折叠；事实全部保留、保序 | workflow.mjs:66-107 timelineNodes | 新增「only genuinely keepalive beats fold…」：真实形状负例（cards 关闭通知、state claimed→unknown、session s1→s2）各自单列，纯保活仍折成 h2/h1；QA 仍折叠 6 条 |
| 3 | closed 无 result 一律称「已人工结案」 | 改「已关闭（仅告知或已结案），没有处理结果记录；面板不补写未发生过的处理。」旧断言（QA 要求「已人工结案」）同步更正为「不得出现人工」 | app.js:267 resultText；QA browser-qa.mjs 第 6 段 | 新增 dashboard/app-text.test.mjs（vm 取 resultText 片段）断言含「没有处理结果记录」且不含「人工」；QA 该项改名并通过；round3 独立探针 3/3 通过 |
| 4 | unknown 详情写「已超出重试范围」 | 改按中心租约语义：中心还没有确认这轮结束状态（例如运行中超过租约仍未回报），不猜原因；仍不接受取消、无伪造停止入口 | app.js:351 stopNote | app-text.test.mjs 断言源码不含「超出重试范围」且含「运行中超过租约仍未回报」「不接受取消」；QA unknown 项文案逐字通过 |
| 5 | 空 lane 断言「未设 parallel」 | 改「对象标识为空；只按规则 + 对象归组，不推断是否配过 parallel，也不倒推历史规则」；分组逻辑不动（仍是权威 rule+lane） | workflow.mjs:59-64 itemNote | server.test.mjs 断言含「对象标识为空」「不推断」且不含「未设 parallel」 |
| 6 | 取消后刷新可能被跳过/失败，却用旧 latest 判确认；恢复历史页会清 stale | refresh 返回本次读取的明确结果（被跳过 false、成功 true、失败 false）；提交后先取 `latestOk` 与 `confirmed`（仅最新读成功时非空），再恢复较早页；恢复读取的结果不参与本次措辞 | app.js:74 refresh 返回值、:527-540 提交路径 | 新增「a skipped or failed read cannot confirm a cancel from the older snapshot」（旧快照含 cancelled 也不得据此确认）；新增「cancel wording is decided by that read's own result, before any page restore」（取值顺序在恢复之前、措辞只用 latestOk/confirmed） |

### v2 数字

- 服务端单测：`cd dashboard && node --test server.test.mjs app-text.test.mjs` → tests 34 / pass 34 / fail 0（约 0.41s）；v1 的 28 项全部保留且通过。
- 浏览器（只复测受影响路径）：`node evidence/dashboard-workflow/browser-qa.mjs` → 11 项 / 11 通过 / 0 失败（重启 fixture 后）；折叠组仍为 6 条，unknown 与关闭卡片文案为新版逐字。
- 格式化：prettier --check 本轮 5 个改动文件（workflow.mjs、app.js、server.test.mjs、app-text.test.mjs、browser-qa.mjs）全部通过。
- 未重跑真实中心只读探针（本轮未改 server.mjs 与 lane 逻辑，v1 的 35 轮 / 17 事项结果仍属 v1 证据）。

### v2 边界

- 隔离场景 6 的覆盖在单元层（cancelNote 纯函数 + 提交取值顺序断言）：未新增浏览器脚本模拟「刷新进行中提交取消」与「最新读失败但旧页成功」两条时序，仍需统筹或 B 复核时决定是否补浏览器级时序用例。
- v1 包保持原样可回退；v2 是覆盖式全文件包，应用前同样先备份 dashboard/ 目录。
