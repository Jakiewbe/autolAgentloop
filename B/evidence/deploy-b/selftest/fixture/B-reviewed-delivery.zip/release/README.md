SIMULATED FIXTURE - not the reviewed delivery
