
import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
const argv = process.argv.slice(2);
const opt = {};
for (let i = 0; i < argv.length; i += 2) opt[argv[i].replace(/^--/, "")] = argv[i + 1];
const root = opt.root;
const release = path.dirname(fileURLToPath(import.meta.url));
const sha = d => createHash("sha256").update(d).digest("hex");
const pkg = sha(readFileSync(path.join(release, "agent-autoloop-reviewed.zip")));
const app = path.join(root, "runtime", pkg.slice(0, 12));
const home = path.join(homedir(), ".agent-autoloop");
if (existsSync(path.join(home, "config.json"))) { console.error("exists"); process.exit(3); }
mkdirSync(app, { recursive: true });
mkdirSync(home, { recursive: true });
writeFileSync(path.join(home, "config.json"), JSON.stringify({ url: opt["center-url"], worker: { name: opt["worker-name"], key: "SIMULATED-NOT-A-KEY", capacity: 1 } }, null, 2));
writeFileSync(path.join(root, "B-install-receipt.json"), JSON.stringify({ machine: "B", worker: opt["worker-name"], package_sha256: pkg, pid: process.pid, app, status: "worker-started-only", model_verified: false, cross_network_task_verified: false }, null, 2));
console.log("SIMULATED INSTALL: no service, no network");
