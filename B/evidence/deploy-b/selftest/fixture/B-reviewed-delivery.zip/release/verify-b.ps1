param(
  [Parameter(Mandatory=$true)][ValidateSet('claude','codex')][string]$Agent,
  [Parameter(Mandatory=$true)][string]$Executable,
  [Parameter(Mandatory=$true)][string]$Model,
  [string]$SettingsFile,
  [string]$OutputDirectory = '.'
)
Write-Output 'SIMULATED VERIFY OK'
exit 0
