# B 部署包交付说明

本包由 A 审核后的实际源码生成，包含 Windows 运行适配、Claude/Go 接口及严格的模型结果验证器。
用户已确认 B 没有远程执行入口，因此本轮只交付包，不宣称已经在 B 安装或完成跨网络验收。
该包用于受控部署验证，尚未通过整体上线验收：关键回归57项通过，原交付的完整Windows回归244项通过、64项失败、2项跳过，详见A的本轮审核报告。不要直接启用真实业务自动写入。

## 执行前必须具备

1. B 本机 Node 24+；B 现有报告已记录，但安装时仍检查。
2. 从 B 可访问的 A 私网或受保护 HTTPS 地址。A 当前仍只监听 127.0.0.1:3350，这个地址不能直接填给 B。
3. A 为 B 单独签发的 worker 身份文件，通过私密方式交给 B；不上传 GitHub，不复用 A 管理员身份。
4. A 的规则已登记 B 执行端及 B 实际模型、目录。安装脚本只启动 worker，不建立第二个中心，也不替用户编造模型可用性。

在 A 已打通连接后，以其管理 CLI 签发 B 身份：`key new worker b-magicbook14`。
输出属于秘密，应直接保存到 A 私有运行目录并私密交给 B；不能复制到聊天、部署清单或仓库。

## B 安装

把整个 B 部署包解压到 D 盘目录，打开命令行，执行：

```powershell
node .\install-b.mjs --center-url "A的实际私网或受保护HTTPS地址" --worker-key-file "B本机私有身份文件路径" --root "D:\AutoAgentloop"
```

脚本先验证连接及身份，后核对部署包和解包文件。已有配置或目标目录时停止，不覆盖旧现场。
成功时只报告 worker 启动，生成 B-install-receipt.json；不把这一回执当成模型或双机验收通过。
后台入口是登录启动，尚未实际注销/登录验证；不会声称无人登录时也已验证可运行。

## 模型与功能复验

B 的既有报告中，Claude 原生入口是 `C:\Users\19082\.local\bin\claude.exe`，成功调用过的明确模型 ID 是 `deepseek-v4.1-flash-1017`。
这只是历史记录，执行时须核对 B 本机入口及配置；不能引用 A 的成功作为 B 通过。

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\verify-b.ps1 -Agent claude -Executable 'C:\Users\19082\.local\bin\claude.exe' -Model 'deepseek-v4.1-flash-1017' -SettingsFile 'B实际私有Claude配置文件'
```

新脚本校验真实进程退出码、结构化最终结果、准确回复和会话。失败或缺少配置就停止，不用 grep 搜索提示词、不把 DSH 跳过计为通过。
此项只验证模型回复；编辑、运行检查、同会话接续、任务回传和跨网络恢复必须另行实测。
DSH 尚未接入当前部署，不能用曾经的 headless 文字回复冒充 ACP 接续及取消通过。

完成后把无秘密的安装回执及复验日志交回 A，由 Codex 按实际材料复验。
