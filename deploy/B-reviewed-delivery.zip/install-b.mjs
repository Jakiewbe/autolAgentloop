// Windows worker-only installer. Secrets stay in the user's private home and never in the release directory.
import { createHash } from "node:crypto";
import { execFileSync, spawn } from "node:child_process";
import { closeSync, existsSync, mkdirSync, openSync, readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import path from "node:path";
import { parseArgs } from "node:util";
import { fileURLToPath } from "node:url";

const { values } = parseArgs({ options: {
  "center-url": { type: "string" }, "worker-key-file": { type: "string" },
  root: { type: "string", default: "D:/AutoAgentloop" },
  "worker-name": { type: "string", default: "b-magicbook14" },
} });
if (process.platform !== "win32" || Number(process.versions.node.split(".")[0]) < 24) throw new Error("此部署包需要Windows和Node 24+");
if (!values["center-url"] || !values["worker-key-file"]) throw new Error("需要 --center-url 与 --worker-key-file；不能从仓库获取身份秘密");
const center = new URL(values["center-url"]);
if (!["http:", "https:"].includes(center.protocol) || center.username || center.password) throw new Error("中心地址必须是无内嵌凭据的HTTP(S)地址");
const base = center.href.replace(/\/$/, "");
const key = readFileSync(values["worker-key-file"], "utf8").trim();
if (!key) throw new Error("B身份文件为空");
const health = await fetch(base + "/healthz", { signal: AbortSignal.timeout(10000) });
if (!health.ok) throw new Error(`中心健康检查失败：${health.status}`);
const auth = await fetch(base + "/v1/work?claim=installer-check&wait=0&running=&capacity=0", {
  headers: { authorization: `Bearer ${key}` }, signal: AbortSignal.timeout(15000),
});
if (!auth.ok) throw new Error(`B身份检查失败：${auth.status}`);
const release = path.dirname(fileURLToPath(import.meta.url));
const manifest = JSON.parse(readFileSync(path.join(release, "manifest.json"), "utf8"));
const archive = path.join(release, "agent-autoloop-reviewed.zip");
const sha = data => createHash("sha256").update(data).digest("hex");
if (sha(readFileSync(archive)) !== manifest.package.sha256) throw new Error("部署包哈希不符");
const app = path.resolve(values.root, "runtime", manifest.package.sha256.slice(0, 12));
const home = path.join(homedir(), ".agent-autoloop");
if (existsSync(path.join(home, "config.json")) || existsSync(app)) throw new Error("配置或版本目录已存在，停止以保留现场");
mkdirSync(path.dirname(app), { recursive: true });
mkdirSync(app);
execFileSync(path.join(process.env.SystemRoot ?? "C:/Windows", "System32", "tar.exe"), ["-xf", archive, "-C", app], { windowsHide: true });
for (const file of manifest.files) {
  if (sha(readFileSync(path.join(app, file.path))) !== file.sha256) throw new Error(`解包文件不符：${file.path}`);
}
mkdirSync(home, { recursive: true });
writeFileSync(path.join(home, "config.json"), JSON.stringify({ url: base, worker: { name: values["worker-name"], key, capacity: 1 } }, null, 2), { flag: "wx" });
const env = { ...process.env, AGENT_AUTOLOOP_HOME: home };
const entry = path.join(app, "bin", "agent-autoloop.ts");
execFileSync(process.execPath, ["--disable-warning=ExperimentalWarning", entry, "service", "install"], { env, windowsHide: true, stdio: "inherit" });
mkdirSync(path.join(home, "logs"), { recursive: true });
const out = openSync(path.join(home, "logs", "worker.stdout.log"), "a");
const err = openSync(path.join(home, "logs", "worker.stderr.log"), "a");
const worker = spawn(process.execPath, ["--disable-warning=ExperimentalWarning", entry, "up"], { cwd: app, env, detached: true, windowsHide: true, stdio: ["ignore", out, err] });
let startError;
worker.on("error", error => { startError = error; });
await new Promise(resolve => setTimeout(resolve, 2000));
closeSync(out); closeSync(err);
if (startError) throw startError;
if (worker.exitCode !== null || worker.signalCode !== null) throw new Error("B执行端已退出，请检查本机日志");
worker.unref();
const receipt = { machine: "B", worker: values["worker-name"], package_sha256: manifest.package.sha256, pid: worker.pid, app, status: "worker-started-only", model_verified: false, cross_network_task_verified: false };
writeFileSync(path.resolve(values.root, "B-install-receipt.json"), JSON.stringify(receipt, null, 2));
console.log("B执行端已启动，回执已保存；模型、任务回传和恢复仍需实测，不能记为完整通过。");
