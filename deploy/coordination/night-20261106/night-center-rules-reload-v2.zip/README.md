# night-center-rules-reload-v2（A 中心专用，B 侧不应用）

## 这份包补的是 v1 漏掉的那一刀

v1（`night-center-rules-reload-v1.zip`，10080B，`da01ff6c...31cfc8`）只装了 `app/host/runtime.ts` 的
ENOENT 守卫和它的测试。它挡的是新文件 move 到位前那一瞬文件不存在，但 **rules.json 改动从不热加载**
的真正原因在 `app/host/server.ts`：

    file !== RULES_FILE.split("/").at(-1)

Windows 的 `RULES_FILE` 只有反斜杠（`C:\Users\chs\.agent-autoloop\rules.json`），`split("/")` 永远只有
一个元素，比较永远为真，watcher 从来没认过 rules.json。

## 改动（两处，都很小）

`app/host/server.ts`
- 新增 `const rulesName = basename(RULES_FILE);`
- 判等改成 `file !== rulesName`

`app/host/runtime.ts`
- `gone(error)` = `code === "ENOENT"`
- `reloadRules()` 的 `statSync` 与读取都用 `gone()` 守卫，返回 `{ changed: false }`；
  一个正在被替换的文件不会让 watcher 抛出、把整个 hub 打死

`app/tests/rules.test.ts`
- 新增用例：a file missing for the moment between the old one and the new one keeps the rules running

## 完整哈希（before = main HEAD c4a6434 的字节，after = 应用后字节）

- `app/host/server.ts`        4422B -> 4816B
  before `5e988129a6eda8b45dc63be245361ce25eafb5489660a03c7550a97af8821c6f`
  after  `7ef50b1eae27c8a293b0fac95ad36429471fde909485b1fe09d82d8562b6ae5d`
- `app/host/runtime.ts`      12636B -> 13440B
  before `288bf961464220f23d55f740640325f864b5998f6abbfdddbbbced85dfa2b9f8`
  after  `c15d0bd3c5d90251c640f282e3b66321779b26fcee20ed40c068e9d929286798`
- `app/tests/rules.test.ts`   7601B -> 8331B
  before `e4dee032b015206cd6bad201079ef44e6a9c372325a61bba6dc9f591ffd5b247`
  after  `982f4e7cc38943dcde4b00eb1e164a24182b7362cde8fb5ee68ac62104746a46`

## 已在 A 生效（不是计划应用）

- server.ts 修复早于 2026-11-05 00:33 已在工作树；runtime.ts 于 2026-11-06 01:59:09 写入
- hub 于 2026-11-06 02:00:05 重启（同一命令）加载两者
- 现场证据：新增规则后 event 29 的 ack 立即 `routed=["B-断线恢复"]`，无需重启即生效
- 该次重启在夜间封存报告里被误写成未重启 A 中心，已在 summary.md 勘误；重启只动 A 的 hub 进程，
  未动 MCP、ACL、登录项、B 侧任何文件

## 校验

- `node --test app/tests/rules.test.ts` -> 7 tests, pass 7, fail 0
- `npx -y -p typescript@5.9.3 tsc -p app` -> 通过

## 回退

按 beforeSha256 覆盖回文件，重启 hub。
