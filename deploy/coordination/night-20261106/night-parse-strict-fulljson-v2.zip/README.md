# NIGHT-20261106 候选包 vA2（parse-strict-fulljson-v2）

以包内 `PATCH.json` 为准。本包只含 3 个源文件，不含二进制、不含 MCP 配置、不含任何身份材料。

## 这份包和 v1 的区别（v1 已撤销）

v1（`night-parse-terminal-boundary-v1.zip`，13090B，`254b44b1...502b27`）在 `read()` 里加了一个
终态事件之后不再判协议错的边界。它确实让 run18 那种输出能出结果，但那是**放宽判分**：
同样的字节在旧代码报错、在新代码通过，等于用判分让步掩盖通道缺陷。本包把这条边界删掉。

现在的规则：**Codex JSONL 的每一行都是协议**。任何一行不是 JSON 对象 —— 不论它在
`turn.completed` 之前还是之后 —— 整轮失败，错误里报出行号，原始 stdout 一字不改地留在日志里。
`error` / `turn.failed` 事件照旧拒绝。没有 taskkill 白名单，没有噪声行可跳过的特例。

包内 `worker/agents.ts` 与 v1 逐字节相同；`plugins/command/agent.ts` 从 v1 的 `1b8933c0...` 变成
`c077041d...`（6141B）；`worker/worker.ts` 在 v1 基础上多修一处（见下）。

### worker/worker.ts 里新修的一处（严格判分让它变成常见路径）

`discardReceipt()` 原来写 `readMessage(reading.text!)`。回声不可读时 `reading.text` 恰恰是 undefined，
`readMessage` 会对它调 `matchAll` 直接抛 TypeError —— 那是「回执读不懂」这条兜底路径自己炸掉。
严格判分后 error 且无 text 是常见结果，这一炸会命中。改成 `readMessage(reading.text ?? "")`，
按「没留下结果」记一次失败并保留 notice。

## 一条必须说清的后果

严格判分下，**只要 Codex 自己往 stdout 打了一行非 JSON，这一轮就是失败**。run18 的那三条
`成功: 已终止 PID ...` 来自启动它的清理动作没有重定向输出，属于通道侧缺陷，不是解析端该容忍的东西。
正确做法是让通道不再往 stdout 打这些行（重定向/隐藏窗口/改用不打印的终止方式），而不是放宽解析。
治本那一刀本轮没有做，也不该由解析端兜。

## 成员校验（应用前后都核）

- `plugins/command/agent.ts`  6141B  after `c077041d0f2ac21b774ba546d203c16a81e2954b44770b27dedc7d5b831c4f74`
- `worker/agents.ts`          2328B  after `6c150fc07d6ec255df6aadc6cc73192d829333dda7b18d276ce8574d0e23b471`（同 v1）
- `worker/worker.ts`        17335B  v1 应用后 `9899c232...`，本包 after 见 PATCH.json（多一处 discardReceipt 修复）

`agent.ts` 的三种可能 before：runtime 基座 `f821c0b0...`、旧 command-result-fix 补丁后 `ac23aa9b...`、
v1 包后 `1b8933c0...`。若现场哈希既不是三者之一也不是 after，停下，不要硬覆盖。

## A 侧离线验证（本轮，未部署）

- `node --test app/tests/command-adapter.test.ts` -> 15 tests, pass 15, fail 0
  （新增两条：终态后 3 条 taskkill 噪声必须让整轮失败；用 0.166 入口的实际 argv
  `...\22cfb1d302613eae\codex.exe exec resume <id> --skip-git-repo-check --json -m deepseek-v4.1-flash-1017 P`
  对 6 种全非法输出断言都有 error、text 为 undefined；把 codex.exe 改名成 codex-0166.exe 的反例退回纯文本，
  说明识别是按标准文件名 + `--json`）
- `npx -y -p typescript@5.9.3 tsc -p app` -> 通过（无输出）
- `npx prettier --check` 两个改动文件 -> 通过
- run18 真实字节回放（`evidence/raw/night/run18-replay.mts`，不调用模型）：38 行、非 JSON 行 36/37/38、
  结果 `{"error":"Codex stdout 第 36 行不是 JSON 对象，原始输出保留在日志中","session":"01a1ab19-c2f1-7681-aa54-8c3971d344d6"}`
  —— 严格版按预期失败，与 run18 当时中心记录一致

`app/tests/worker.test.ts` 在 Windows 上多条失败（测试写死 `/bin/sh`，POSIX-only），本轮未改该文件，与本包无关。

## 应用与回退（B 机器，本轮不执行）

1. 停当前 worker（维护重启，只停该进程，核对实际 PID）
2. 记录 3 个目标文件现有 sha256
3. 解压覆盖到运行时对应路径
4. 核对 3 个 afterSha256
5. 只启动该 worker，核对心跳与文件哈希；不动 MCP、ACL、登录项
6. 回退：用第 2 步备份覆盖回 beforeSha256

## 边界

不夹带任何其他改动；不含原始 stdout/stderr、rollout、完整 argv/env、身份或登录材料。
