# NIGHT-20261106 补充包 vA1：Codex 协议流终态边界（解析端）

包名 mem 与 PATCH.json 为准；本包只含 3 个源码文件，不含二进制、MCP 配置、规则文件或判分器。

## 解决的实际问题
run18（固定提交 c71bd2d 的证据包）真实字段：stdout 共 38 行，第 1–35 行是 JSON，第 35 行是 turn.completed，
第 36–38 行是 Codex 自身清理阶段未重定向的三条 taskkill 成功提示。旧解析把这些行当成协议污染，
整轮被记为“Codex stdout 第 36 行不是 JSON 对象”，已完成的回合和 usage 被丢弃。

## 改了什么
1. plugins/command/agent.ts：解析到 turn.completed / turn.failed 之后，把后续非 JSON 行视为协议流之外的进程清理输出，
   不再据此判失败；原始 stdout 日志逐字保留，不做删除或改写。终态之前的任何非 JSON 行仍失败。
   缺终态、缺最终 agent_message、缺 thread_id、usage 非有限非负数字仍失败；判分字段与期望回复校验未改动。
2. worker/worker.ts：进程结束后按完整字节读取 stdout 做最终判定（运行中仍用可增量快照），避免尾部丢失。
3. worker/agents.ts：适配器读取返回类型 Reading 与 Usage 的显式导出（第 1 项所需的类型面）。

## 成员与哈希（解压后逐个复核）
（见 PATCH.json files[].afterSha256 / bytes）

## 适用 before（三种情形，先核对再覆盖）
- 运行时为 base d504e4876d07 原样：agent.ts=f821c0b0…，agents.ts=fae427d4…，worker.ts=a68379be…
- 已应用过旧包 command-result-fix（v1）：agent.ts=ac23aa9b…，agents.ts=6c150fc0…，worker.ts=9899c232…（后两者与本包一致，跳过即可）
- 其他任何哈希：停止，不覆盖，回执写明实际哈希等 A 判断。

## 应用与回退（仅 B 执行端维护窗口，A 不代做）
1. 在 B 机定位当前 worker 使用的运行时根（item6 证据：D:\AutoAgentloop\runtime\d504e4876d07），先停本轮明确对象（该 worker 进程），核对 PID 与心跳停止。
2. 备份将覆盖的三个文件到独立备份目录，记录原文件 sha256。
3. 解压本包，把 plugins/command/agent.ts、worker/agents.ts、worker/worker.ts 覆盖到运行时根的对应相对路径。
4. 复核覆盖后三个文件 sha256 与 PATCH.json afterSha256 一致。
5. 只重启该 worker 进程（维护重启），核对新 PID、心跳上线、运行时根与文件哈希；不改 MCP 配置、不改 ACL/标签、不改登录项。
6. 回退：停该 worker，用第 2 步备份覆盖回原名，复核 beforeSha256，再启动；回执写清回退原因。

## A 侧离线验证（无模型调用）
- app 单元测试：node --test app/tests/command-adapter.test.ts → 14 项全过。
- 类型检查：npx tsc -p app 通过。
- 真实字节回放：用 run18 捕获的 stdout/stderr（25424 字节，sha256 96921199…）离线跑修复后解析器，
  得到 text=“B 接线验证文件已按规则完成并核验通过。”、session=01a1ab19-c2f1-7681-aa54-8c3971d344d6、
  usage={input:942037,output:3246,cached:933632}；同一份字节在旧代码下报第 36 行错误。
- 说明：仓库 app/tests/worker.test.ts 使用 /bin/sh 等 POSIX 脚本，在 Windows 上本就多处失败（平台原因，非本包引入，
  worker.test.ts 在本轮无改动）。

## 脱敏
本包与说明不含原始 stdout/stderr 全文、rollout、完整 argv/env、配置文件、身份或登录材料；run18 仅引用公开过的统计字段与哈希。
