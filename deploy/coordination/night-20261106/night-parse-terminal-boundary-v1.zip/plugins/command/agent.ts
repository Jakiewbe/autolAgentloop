// Anything with a print mode: its command line in rules.json, its last message on stdout. A script is an agent too, and
// a plain command needn't take the prompt at all: it finds what it needs through the environment (AGENT_AUTOLOOP_CONTEXT).
//
// Two placeholders stand for a list rather than a word, because going on in a session changes the command line itself:
// {resumeArgs} is `resume <会话>` when there is a session to go on in, nothing on the first turn; {cwdArgs} is `-C <目录>`
// on the first turn, nothing when going on (codex's resume takes no -C). A session id printed in the output as a JSON line
// with thread_id / threadId / sessionID / session_id is reported, so the next turn goes on in it.
import { basename } from "node:path/win32";
import { tail, type Adapter, type Reading, type Turn, type Usage } from "../../worker/agents.ts";

const SESSION_KEYS = ["thread_id", "threadId", "sessionID", "session_id"];

function argv(turn: Turn): string[] {
  const out: string[] = [];
  for (const part of turn.command ?? []) {
    const token = part.trim();
    // A part that is only a placeholder standing for arguments expands to none, one, or several words.
    if (token === "{resumeArgs}") {
      if (turn.resume) out.push("resume", turn.resume);
      continue;
    }
    if (token === "{cwdArgs}") {
      if (!turn.resume) out.push("-C", turn.cwd);
      continue;
    }
    if (token === "{sessionArgs}") {
      if (turn.resume ?? turn.session) out.push("--session", turn.resume ?? turn.session);
      continue;
    }
    out.push(
      part
        .replaceAll("{prompt}", turn.prompt)
        .replaceAll("{model}", turn.model ?? "")
        .replaceAll("{effort}", turn.effort ?? "")
        .replaceAll("{cwd}", turn.cwd)
        .replaceAll("{session}", turn.resume ?? turn.session)
        .replaceAll("{context}", turn.contextFile),
    );
  }
  return out;
}

export default {
  command: (turn) => argv(turn),
  read(stdout, code, stderr, source?: Pick<Turn, "command">): Reading {
    // Parse once at the output boundary. Plain-text commands may carry session
    // metadata; Codex JSONL is a protocol and must never fall back to raw text.
    const events: Record<string, unknown>[] = [];
    let invalidLine: number | undefined;
    let session: string | undefined;
    // The turn's protocol stream ends at its terminal event. Codex's own cleanup can print plain
    // lines after that on the same stdout (run 18 carries three unredirected taskkill lines after
    // turn.completed); those are not part of the turn, stay untouched in the raw log, and must not
    // turn a completed turn into a protocol error. Anything before the terminal event stays fatal.
    let ended = false;
    for (const [index, line] of stdout.split(/\r?\n/).entries()) {
      if (!line.trim()) continue;
      let value: unknown;
      try {
        value = JSON.parse(line);
      } catch {
        if (!ended) invalidLine ??= index + 1;
        continue;
      }
      if (typeof value !== "object" || value === null || Array.isArray(value)) {
        if (!ended) invalidLine ??= index + 1;
        continue;
      }
      const event = value as Record<string, unknown>;
      events.push(event);
      if (event.type === "turn.completed" || event.type === "turn.failed") ended = true;
      for (const key of SESSION_KEYS) {
        const id = event[key];
        if (typeof id === "string" && id) session = id;
      }
    }
    const known = session ? { session } : {};
    if (code === null) return known;
    if (code !== 0) return { error: `退出码 ${code}：${tail(stderr || stdout) || "没留下原因"}`, ...known };
    const command = source?.command ?? [];
    const codexCommand =
      /^codex(?:\.(?:exe|cmd|bat))?$/i.test(basename(command[0] ?? "")) && command.includes("--json");
    const codexEvents = events.some((event) =>
      ["thread.started", "turn.started", "turn.completed", "turn.failed", "item.completed"].includes(
        event.type as string,
      ),
    );
    if (!codexCommand && !codexEvents) return { text: stdout, ...known };
    if (invalidLine !== undefined)
      return { error: `Codex stdout 第 ${invalidLine} 行不是 JSON 对象，原始输出保留在日志中`, ...known };
    const failed = events.find((event) => event.type === "turn.failed" || event.type === "error");
    if (failed) {
      const detail = failed.error as { message?: unknown } | undefined;
      const message = failed.message ?? detail?.message;
      return { error: typeof message === "string" && message ? message : "Codex 本轮失败", ...known };
    }
    const completed = events.findLast((event) => event.type === "turn.completed");
    if (!completed) return { error: "Codex 没有成功完成本轮", ...known };
    const codexSession = events.find((event) => event.type === "thread.started")?.thread_id;
    if (typeof codexSession !== "string" || !codexSession.trim()) return { error: "Codex 没有返回会话编号" };
    let text: unknown;
    for (const event of events) {
      const item = event.item as { type?: unknown; text?: unknown } | undefined;
      if (event.type === "item.completed" && item?.type === "agent_message") text = item.text;
    }
    if (typeof text !== "string" || !text.trim()) return { error: "Codex 没有留下最终回复", session: codexSession };
    const usage: Usage = {};
    if (completed.usage !== undefined) {
      if (typeof completed.usage !== "object" || completed.usage === null || Array.isArray(completed.usage))
        return { error: "Codex usage 必须是对象", session: codexSession };
      const given = completed.usage as Record<string, unknown>;
      for (const [from, to] of [
        ["input_tokens", "input"],
        ["output_tokens", "output"],
        ["cached_input_tokens", "cached"],
      ] as const) {
        const value = given[from];
        if (value === undefined) continue;
        if (typeof value !== "number" || !Number.isFinite(value) || value < 0)
          return { error: `Codex usage.${from} 必须是有限非负数字`, session: codexSession };
        usage[to] = value;
      }
    }
    return { text, session: codexSession, ...(Object.keys(usage).length ? { usage } : {}) };
  },
} satisfies Adapter;
