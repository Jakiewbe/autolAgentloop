# night-center-rules-reload-v1（A 中心专用，B 侧不需要应用）

## 问题（已复现）
A 中心热加载 rules.json。01:55:42 换文件时，旧文件与临时文件之间有一个短暂缺失窗口，
watcher 回调 app/host/server.ts:102 → app/host/runtime.ts:157 tick → runtime.ts:114 statSync，
抛出未捕获 ENOENT，进程退出：

    Error: ENOENT: no such file or directory, stat C:\Users\chs\.agent-autoloop\rules.json

窗口 01:55:42–02:00:05，期间没有 in-flight run（16/17 done，18 cancelled）。

## 改动（最小）
app/host/runtime.ts
- 新增 const gone = (error: unknown) => (error as NodeJS.ErrnoException)?.code === "ENOENT";
- reloadRules() 的 statSync/readFileSync 分支遇 ENOENT 返回 { changed: false }，保留上一版规则继续运行；
  其他错误照旧抛出，不做静默吞掉。

app/tests/rules.test.ts
- 新增用例「a file missing for the moment between the old one and the new one keeps the rules running」。

## 哈希
- app/host/runtime.ts        before 288bf961464220f23d55f740640325f864b5998f6abbfdddbbbced85dfa2b9f8
                            after  c15d0bd3c5d90251c640f282e3b66321779b26fcee20ed40c068e9d929286798 (13440 B)
- app/tests/rules.test.ts   before e4dee032b015206cd6bad201079ef44e6a9c372325a61bba6dc9f591ffd5b247
                            after  982f4e7cc38943dcde4b00eb1e164a24182b7362cde8fb5ee68ac62104746a46 (8331 B)

## 验证（A 侧本地）
- node --test app/tests/rules.test.ts → 7 tests, pass 7, fail 0
- npx tsc -p app → 通过
- 中心在 02:00:05 按原命令恢复（node --disable-warning=ExperimentalWarning bin/agent-autoloop.ts up，pid 44848），
  02:00:07 tunnel 200，B worker 02:00:21 恢复心跳；本包不含任何 ACL/标签/MCP/登录项变更。

## 应用与回退
- 本包只针对 A 中心 hub 进程；B 侧 worker 不需要应用，也不要在 B 上覆盖这两个文件。
- 回退：把上面 before 哈希的两个文件按字节还原，重启中心即恢复旧行为（旧行为会在换文件窗口崩溃）。

## 脱敏
只含源码与测试，不含身份、token、原始 stdout/stderr、argv、env 或登录材料。
