// The rules file is what the owner changes by asking an Agent, so a mistake must be caught, say which rule and what is
// wrong, and leave the old rules running. Failure cases: a rule naming a source or agent that isn't there; two rules with
// one name; a rule matching no event or with both a source and a schedule; a schedule that is malformed or never comes; an
// unknown way of telling; an agent without a worker, with an unknown access level, or a command without a command line;
// a rule with neither a skill nor a prompt, or without a folder; a misspelt field taken silently; a rule running more
// than one at a time without saying how many, or rules in one group disagreeing on it; an emit naming a source that isn't
// there; a scheduled task shown on the page naming a source or agent that isn't there or a malformed schedule; a time zone
// that doesn't exist; the reserved source redefined; a null rule crashes reload instead of keeping the old rules.
// A good file changing on disk takes effect; a bad one doesn't, and says why.
import assert from "node:assert/strict";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { test } from "node:test";
import { setup } from "./helpers.ts";

const home = setup("rules");
const { parseRules, RulesError, rules, ruleNamed, rulesFor, workers, agentsOf, limitOf, reloadRules, typeMatches } =
  await import("../host/runtime.ts");

const good = () => JSON.parse(readFileSync(join(import.meta.dirname, "rules.fixture.json"), "utf8"));
const problem = (change: (r: any) => void, words: RegExp) => {
  const r = good();
  change(r);
  assert.throws(
    () => parseRules(JSON.stringify(r)),
    (error: Error) => {
      assert.ok(error instanceof RulesError);
      assert.match(error.message, words);
      return true;
    },
  );
};

test("the fixture loads, with defaults filled in", () => {
  const r = parseRules(JSON.stringify(good()));
  assert.equal(r.rules[0].tell, "needed");
  assert.equal(r.rules[2].group, "告警也记一笔", "a rule's group defaults to its own name");
  assert.ok(r.askFirst.includes("删数据"));
  assert.equal(r.sources.schedule.name, "定时");
  assert.equal(r.agents.a1.access, "edit", "the safe level unless the rule's author asks otherwise");
  assert.equal(r.agents.a2.access, "full");
});

test("a mistake says which rule and what is wrong", () => {
  problem((r) => {
    r.rules[0].to = "nobody";
  }, /规则「意见」.*to.*不是已登记的 Agent：nobody/);
  problem((r) => {
    r.rules[0].when.source = "nowhere";
  }, /规则「意见」.*来源.*nowhere/);
  problem((r) => {
    r.rules[1].name = "意见";
  }, /规则名「意见」重复了/);
  problem((r) => {
    r.rules[0].when.types = [];
  }, /规则「意见」.*types/);
  problem((r) => {
    r.rules[0].when.cron = "0 9 * * *";
  }, /规则「意见」.*when/);
  problem((r) => {
    r.rules[3].when.cron = "99 * * * *";
  }, /规则「早报」.*cron/);
  problem((r) => {
    r.rules[3].when.cron = "0 0 30 2 *";
  }, /规则「早报」.*不会到来/);
  problem((r) => {
    r.rules[0].tell = "sometimes";
  }, /规则「意见」.*tell/);
  problem((r) => {
    delete r.rules[0].cwd;
  }, /规则「意见」缺少 cwd/);
  problem((r) => {
    r.rules[0].cwd = "relative/path";
  }, /规则「意见」.*cwd/);
  // On Windows an absolute folder starts with a drive letter or a share, not with a slash: init writes one there.
  for (const folder of ["C:\\project\\notes", "c:/project/notes", "\\\\share\\notes", "~/notes", "/notes"]) {
    const written = good();
    written.rules[0].cwd = folder;
    assert.doesNotThrow(() => parseRules(JSON.stringify(written)), folder);
  }
  problem((r) => {
    delete r.rules[1].prompt;
  }, /规则「告警」.*skill.*prompt/);
  problem((r) => {
    r.rules[0].oops = 1;
  }, /规则「意见」有不认识的字段 oops/);
  problem((r) => {
    delete r.rules[0].parallel;
    r.rules[1].group = "notes";
    r.rules[1].parallel = 2;
  }, /组「notes」.*parallel/);
  problem((r) => {
    r.rules[0].parallel = 0;
  }, /规则「意见」.*parallel/);
  problem((r) => {
    r.rules[4].emits.source = "nowhere";
  }, /规则「巡检」.*emits/);
  problem((r) => {
    delete r.agents.a1.worker;
  }, /Agent a1 缺少 worker/);
  problem((r) => {
    r.agents.a1.access = "root";
  }, /Agent a1.*access/);
  problem((r) => {
    delete r.agents.a3.command;
  }, /Agent a3.*command/);
  problem((r) => {
    r.agents.a1.oops = 1;
  }, /Agent a1 有不认识的字段 oops/);
  problem((r) => {
    r.sources.schedule = { name: "x" };
  }, /schedule.*保留/);
  problem((r) => {
    r.sources["Bad Id"] = { name: "x" };
  }, /来源的编号/);
  problem((r) => {
    r.channels.chat.answerers = "me";
  }, /通道 chat.*answerers/);
  problem((r) => {
    r.elsewhere[0].to = "nobody";
  }, /定时任务「每周清理」.*to/);
  problem((r) => {
    r.elsewhere[0].source = "nowhere";
  }, /定时任务「每周清理」.*source/);
  problem((r) => {
    r.elsewhere[0].cron = "nope";
  }, /定时任务「每周清理」.*cron/);
  problem((r) => {
    r.elsewhere[0].name = "意见";
  }, /定时任务「意见」.*重名/);
  problem((r) => {
    r.timezone = "Mars/Olympus";
  }, /timezone/);
  problem((r) => {
    r.askFirst = "删数据";
  }, /askFirst/);
  assert.throws(() => parseRules("{ not json"), /不是 JSON/);
});

test("types match exactly, by prefix or all", () => {
  assert.ok(typeMatches(["feedback.*"], "feedback.new"));
  assert.ok(!typeMatches(["feedback.*"], "feedbackx.new"));
  assert.ok(typeMatches(["alert.raised"], "alert.raised"));
  assert.ok(!typeMatches(["alert.raised"], "alert.raised.more"));
  assert.ok(typeMatches(["*"], "anything"));
});

test("a null rule is a rules error and leaves the running configuration intact", () => {
  problem((r) => {
    r.rules = [null];
  }, /对象/);
  const file = join(home, "null-rules.json");
  const broken = good();
  broken.rules = [null];
  writeFileSync(file, JSON.stringify(broken));
  const answer = reloadRules(file);
  assert.equal(answer.changed, false);
  assert.match(answer.problem!, /对象/);
  assert.equal(ruleNamed("意见")!.to, "a1");
});

test("the lookups the hub uses", () => {
  assert.deepEqual(
    rulesFor("ops", "alert.raised").map((r) => r.name),
    ["告警", "告警也记一笔"],
  );
  assert.deepEqual(rulesFor("app", "alert.raised"), []);
  assert.deepEqual(workers(), ["w1", "w2"]);
  assert.deepEqual(agentsOf("w1"), ["a1", "a3"]);
  assert.equal(limitOf("notes"), 3);
  assert.equal(limitOf("ops"), 1);
  assert.equal(ruleNamed("早报")!.to, "a1");
  assert.equal(ruleNamed("没有这条"), undefined);
  assert.equal(rules.timezone, "Asia/Shanghai");
});

test("a good file changing on disk takes effect; a bad one leaves the old rules and says why", () => {
  const file = join(home, "rules.json");
  process.env.AGENT_AUTOLOOP_RULES = file;
  const changed = good();
  changed.rules[0].prompt = "新的说法。";
  writeFileSync(file, JSON.stringify(changed));
  assert.deepEqual(reloadRules(file), { changed: true });
  assert.equal(ruleNamed("意见")!.prompt, "新的说法。");
  assert.deepEqual(reloadRules(file), { changed: false }, "nothing new on disk");
  const broken = good();
  broken.rules[0].to = "nobody";
  writeFileSync(file, JSON.stringify(broken));
  const answer = reloadRules(file);
  assert.equal(answer.changed, false);
  assert.match(answer.problem!, /nobody/);
  assert.equal(ruleNamed("意见")!.prompt, "新的说法。", "the old rules keep running");
});
